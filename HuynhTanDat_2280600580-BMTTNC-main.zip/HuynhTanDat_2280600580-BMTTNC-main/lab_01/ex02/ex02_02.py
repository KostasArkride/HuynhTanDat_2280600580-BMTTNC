# Nhap ban kinh tu nguoi dung
ban_kinh = float(input("Nhap ban kinh cua hinh tron: "))
# Tinh dien tich cua hinh tron
dien_tich = 3.14 * (ban_kinh ** 2)
# In dien tich cua hinh tron ra man hinh
print("Dien tich cua hinh tron la:", dien_tich)