from flask import Flask, request, jsonify
from cipher.rsa import RSACipher

app = Flask(__name__)

rsa_cipher = RSACipher()

@app.route('/api/rsa/generate_keys',method=['GET'])
def rsa_generate_keys():
    rsa_cipher.generate_keys()
    return jsonify({'message': 'Keys generated successfully'})

@app.route("/api/rsa/encrypt", methods=["POST"])
def rsa_encrypt():
    data=request.json
    message = data['message']
    key_type = data['key_type']
    private_key, public_key = rsa_cipher.load_keys()
    if key_type == 'public':
        key = public_key
    elif key_type == 'private'
    
    


